# NOVA-PROTOCOL // Cyberpunk Space Exploration Simulator

[![Status](https://img.shields.io/badge/System-ONLINE-00ffcc.svg)](#)
[![Simulation](https://img.shields.io/badge/Engine-Three.js%20%7C%20Python3-ff007f.svg)](#)
[![Classification](https://img.shields.io/badge/Clearance-LEVEL%205-00e5ff.svg)](#)

> **"Outer perimeter collapsed at 2187 hours. Only the Aegis-Interdictor can penetrate the hyper-dense debris belt and restore Sub-Sector 9."**

Nova-Protocol is an interactive 3D cyberpunk space exploration and tactical interceptor simulator built with WebGL (Three.js), procedural particle physics, zero-latency Web Audio API sound synthesis, and a standalone Newtonian orbital physics engine.

---

## 📁 Project Directory Structure

```text
nova_protocol/
├── index.html                  # Interactive 3D WebGL simulator application
├── styles.css                  # Cyberpunk neon aesthetics, scanlines & glassmorphism
├── config.json                 # Core game balance, keybindings & parameters
├── engine.py                   # Standalone Python orbital mechanics & collision engine
├── nova_protocol_manual.pdf    # Tactical operations manual & system architecture guide
└── README.md                   # Operations & deployment documentation
```

---

## 🚀 Quick Launch Instructions

### 1. Launch Interactive 3D Simulation (Web Browser)
The simulation is fully standalone and can be launched directly in any modern WebGL-compatible browser.

#### Offline Direct Execution:
Simply double-click or open `index.html` directly in Google Chrome, Mozilla Firefox, Microsoft Edge, or Safari.

#### Local HTTP Server (Recommended):
To ensure full CORS and asset pipeline optimization, launch via Python's built-in web server:
```bash
python3 -m http.server 8080
```
Then navigate to: `http://localhost:8080`

### 2. Standalone Python Simulation Verification
Execute the autonomous orbital physics simulation and collision benchmark:
```bash
python3 engine.py
```

### 3. Tactical Manual & Operations Guide
View the included high-fidelity classified manual in your preferred PDF viewer:
- `nova_protocol_manual.pdf`

---

## 🕹️ Flight Controls

| Input Key / Action | Command Execution |
| :--- | :--- |
| **W / Up Arrow** | Engage Primary Ion Thrusters (Pitch & Climb) |
| **S / Down Arrow** | Retro-Thruster Deceleration (Pitch Down) |
| **A / Left Arrow** | Port RCS Burn (Lateral Bank Left) |
| **D / Right Arrow** | Starboard RCS Burn (Lateral Bank Right) |
| **Spacebar** | Fire Twin Coherent Plasma Cannons |
| **Virtual Touch Stick** | 360° Responsive Analog Vectoring (Mobile / Tablet) |
| **Touch "FIRE" Button**| Discharge Plasma Cannons on Mobile |
| **P / ESC** | Pause Simulation & System Telemetry |

---

## ⚡ Technical Highlights

1. **Procedural Particle Thrusters & Warp Starfield:** Over 1,500 dynamic stellar fragments and responsive ion plumes driven by craft velocity.
2. **Audio Synthesizer (Web Audio API):** Multi-oscillator real-time synthesis generates plasma discharge down-chirps, thruster hums, shield recharge resonance, and explosive impacts without any external WAV/MP3 dependencies.
3. **Glassmorphic Cyberpunk HUD:** Real-time Hull integrity, Active Deflector Shields, Radar lock counter, and dynamic scanline CRT overlay.
4. **Mobile Responsive:** Multi-touch on-screen analog joystick and primary trigger with automatic touch device detection.

---

*Mission Protocol Authorized // Deep Space Operations Command*
