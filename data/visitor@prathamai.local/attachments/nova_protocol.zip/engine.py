"""
Nova-Protocol Core Simulation Engine
===================================
A standalone, deterministic Python physics and orbital simulation module.
Provides:
  - Vector3 math operations
  - Spacecraft dynamic rigid body state with thruster dynamics
  - Orbital mechanics (Keplerian orbits, gravitational perturbations, drag)
  - Collision heuristics (Bounding Sphere and Raycast intersections)
"""

import math
import time
from typing import List, Tuple, Optional, Dict, Any

class Vector3:
    """3D Vector with Cartesian geometry operators."""
    __slots__ = ('x', 'y', 'z')

    def __init__(self, x: float = 0.0, y: float = 0.0, z: float = 0.0):
        self.x = float(x)
        self.y = float(y)
        self.z = float(z)

    def __repr__(self) -> str:
        return f"Vector3({self.x:.3f}, {self.y:.3f}, {self.z:.3f})"

    def __add__(self, other: 'Vector3') -> 'Vector3':
        return Vector3(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other: 'Vector3') -> 'Vector3':
        return Vector3(self.x - other.x, self.y - other.y, self.z - other.z)

    def __mul__(self, scalar: float) -> 'Vector3':
        return Vector3(self.x * scalar, self.y * scalar, self.z * scalar)

    __rmul__ = __mul__

    def magnitude_sq(self) -> float:
        return self.x * self.x + self.y * self.y + self.z * self.z

    def magnitude(self) -> float:
        return math.sqrt(self.magnitude_sq())

    def normalized(self) -> 'Vector3':
        mag = self.magnitude()
        if mag == 0.0:
            return Vector3(0.0, 0.0, 0.0)
        return Vector3(self.x / mag, self.y / mag, self.z / mag)

    def dot(self, other: 'Vector3') -> float:
        return self.x * other.x + self.y * other.y + self.z * other.z

    def cross(self, other: 'Vector3') -> 'Vector3':
        return Vector3(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )

    def distance_to(self, other: 'Vector3') -> float:
        return (self - other).magnitude()

    def to_dict(self) -> Dict[str, float]:
        return {"x": self.x, "y": self.y, "z": self.z}


class OrbitalPhysics:
    """Calculates gravitational attractions, orbital velocity, and atmospheric decay."""
    G_CONSTANT = 6.67430e-11

    @staticmethod
    def calculate_gravitational_acceleration(
        craft_pos: Vector3,
        primary_body_pos: Vector3,
        primary_mass: float = 5.972e24
    ) -> Vector3:
        diff = primary_body_pos - craft_pos
        r_sq = diff.magnitude_sq()
        if r_sq < 1.0:
            return Vector3(0, 0, 0)
        r = math.sqrt(r_sq)
        accel_mag = (OrbitalPhysics.G_CONSTANT * primary_mass) / r_sq
        return diff.normalized() * accel_mag

    @staticmethod
    def compute_circular_velocity(radius: float, central_mass: float = 5.972e24) -> float:
        """Returns standard circular orbital velocity v = sqrt(GM/r)."""
        if radius <= 0:
            return 0.0
        return math.sqrt((OrbitalPhysics.G_CONSTANT * central_mass) / radius)

    @staticmethod
    def apply_atmospheric_drag(
        velocity: Vector3,
        air_density: float = 0.001,
        drag_coefficient: float = 0.85,
        reference_area: float = 12.0
    ) -> Vector3:
        speed = velocity.magnitude()
        if speed == 0.0:
            return Vector3(0, 0, 0)
        drag_force_mag = 0.5 * air_density * (speed ** 2) * drag_coefficient * reference_area
        return velocity.normalized() * (-drag_force_mag)


class Spacecraft:
    """Simulates an agile interstellar reconnaissance interceptor."""
    def __init__(self, name: str = "Aegis-Mk4", mass: float = 2400.0):
        self.name = name
        self.mass = mass
        self.position = Vector3(0.0, 0.0, 0.0)
        self.velocity = Vector3(0.0, 0.0, 0.0)
        self.acceleration = Vector3(0.0, 0.0, 0.0)
        self.rotation = Vector3(0.0, 0.0, 0.0) # Pitch, Yaw, Roll in radians
        
        # Craft status
        self.hull = 100.0
        self.shields = 100.0
        self.max_shields = 100.0
        self.thrust_power = 48.0
        self.dampening = 0.94
        self.bounding_radius = 1.8
        self.score = 0

    def apply_force(self, force: Vector3):
        acc = force * (1.0 / self.mass)
        self.acceleration = self.acceleration + acc

    def step(self, dt: float, control_vector: Vector3):
        # Apply pilot input forces
        thrust_force = control_vector * (self.thrust_power * self.mass)
        self.apply_force(thrust_force)

        # Update integration
        self.velocity = (self.velocity + self.acceleration * dt) * self.dampening
        self.position = self.position + self.velocity * dt

        # Visual banking tilt proportional to lateral velocity
        self.rotation.z = -self.velocity.x * 0.04
        self.rotation.x = self.velocity.y * 0.03

        # Clear acceleration accumulator
        self.acceleration = Vector3(0, 0, 0)

        # Shield passive regeneration
        if self.shields < self.max_shields:
            self.shields = min(self.max_shields, self.shields + 4.5 * dt)

    def take_damage(self, damage: float) -> bool:
        if self.shields > 0:
            self.shields -= damage
            if self.shields < 0:
                self.hull += self.shields
                self.shields = 0
        else:
            self.hull -= damage
        return self.hull <= 0.0


class DebrisHazard:
    """Hostile asteroid or debris fragment navigating the cosmic corridor."""
    def __init__(self, position: Vector3, velocity: Vector3, radius: float = 1.5, damage: float = 25.0):
        self.position = position
        self.velocity = velocity
        self.radius = radius
        self.damage = damage
        self.active = True

    def step(self, dt: float):
        self.position = self.position + self.velocity * dt


class CollisionDetector:
    """Fast bounding sphere & raycast intersection tests."""

    @staticmethod
    def sphere_vs_sphere(pos_a: Vector3, rad_a: float, pos_b: Vector3, rad_b: float) -> bool:
        dist_sq = (pos_a - pos_b).magnitude_sq()
        radius_sum = rad_a + rad_b
        return dist_sq <= (radius_sum * radius_sum)

    @staticmethod
    def ray_vs_sphere(
        ray_origin: Vector3,
        ray_direction: Vector3,
        sphere_origin: Vector3,
        sphere_radius: float
    ) -> Optional[float]:
        """Returns distance along ray where intersection occurs, or None."""
        d = ray_direction.normalized()
        m = ray_origin - sphere_origin
        b = m.dot(d)
        c = m.dot(m) - sphere_radius * sphere_radius

        if c > 0.0 and b > 0.0:
            return None
        discr = b * b - c
        if discr < 0.0:
            return None
        t = -b - math.sqrt(discr)
        if t < 0.0:
            t = 0.0
        return t


def run_benchmark():
    """Executes a diagnostic simulation loop verifying numerical stability."""
    print("Initializing Nova-Protocol Simulation Engine...")
    ship = Spacecraft()
    hazards = [
        DebrisHazard(Vector3(0, 0, 20), Vector3(0, 0, -15), radius=2.0),
        DebrisHazard(Vector3(5, -2, 40), Vector3(-1, 0, -18), radius=1.5),
        DebrisHazard(Vector3(-4, 3, 30), Vector3(0.5, -0.2, -12), radius=3.0),
    ]

    dt = 1.0 / 60.0 # 60 FPS tick
    collisions_detected = 0

    for tick in range(120): # Simulate 2 seconds
        # Steering input
        control = Vector3(0.1, 0.0, 0.0) if tick < 30 else Vector3(-0.05, 0.0, 0.0)
        ship.step(dt, control)

        for h in hazards:
            h.step(dt)
            if CollisionDetector.sphere_vs_sphere(ship.position, ship.bounding_radius, h.position, h.radius):
                collisions_detected += 1

    print(f"Simulation Benchmark Completed.")
    print(f"Final Ship Position: {ship.position}")
    print(f"Final Ship Velocity: {ship.velocity}")
    print(f"Final Shield Integrity: {ship.shields:.1f}%")
    print(f"Collisions Tracked: {collisions_detected}")
    return True


if __name__ == "__main__":
    run_benchmark()
