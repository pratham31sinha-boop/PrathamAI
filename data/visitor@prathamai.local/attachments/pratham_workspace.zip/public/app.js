/**
 * PRATHAM AI Autonomous Workspace Frontend Controller
 */

// State
const state = {
  currentFile: 'app.py',
  openTabs: ['app.py'],
  fileTree: [],
  theme: 'dark',
  sidebarOpen: true,
  terminalOutput: "PRATHAM AI Autonomous Terminal v1.0.0 [Online]\nType commands or let the autonomous agent run tasks.\n$ ",
  conversations: [
    { id: 1, title: "Autonomous Coding Session 1" }
  ]
};

// DOM Elements
const chatMessages = document.getElementById('chat-messages');
const chatInput = document.getElementById('chat-input');
const codeEditor = document.getElementById('code-editor');
const terminalView = document.getElementById('terminal-view');
const previewView = document.getElementById('preview-view');
const fileList = document.getElementById('file-list');
const editorTabs = document.getElementById('editor-tabs');
const paletteModal = document.getElementById('palette-modal');
const paletteInput = document.getElementById('palette-input');
const paletteList = document.getElementById('palette-list');

// Command Palette Actions
const commands = [
  { name: "New File", action: () => promptCreateFile() },
  { name: "New Folder", action: () => promptCreateFolder() },
  { name: "Save", action: () => saveCurrentFile() },
  { name: "Run Code / Terminal", action: () => runCurrentFile() },
  { name: "Toggle Sidebar", action: () => toggleSidebar() },
  { name: "Toggle Terminal / Preview", action: () => toggleDock('preview') },
  { name: "Change Theme (Dark/Light)", action: () => toggleTheme() },
  { name: "Clear Chat", action: () => clearChat() }
];

// Initialize
async function init() {
  await fetchFiles();
  await openFile('app.py');
  setupEventListeners();
  renderTabs();
}

// Fetch Files Tree
async function fetchFiles() {
  try {
    const res = await fetch('/api/files');
    const data = await res.json();
    state.fileTree = data.files || [];
    renderFileTree();
  } catch (err) {
    console.error('Failed to fetch files:', err);
  }
}

// Render File Tree
function renderFileTree() {
  fileList.innerHTML = '';
  state.fileTree.forEach(item => {
    const el = document.createElement('div');
    el.className = `file-item ${state.currentFile === item.path ? 'active' : ''}`;
    el.innerHTML = `<span>${item.type === 'directory' ? '📁' : '📄'} ${item.name}</span>`;
    if (item.type === 'file') {
      el.onclick = () => openFile(item.path);
    }
    fileList.appendChild(el);
  });
}

// Open File in Editor
async function openFile(filePath) {
  try {
    const res = await fetch(`/api/file/read?path=${encodeURIComponent(filePath)}`);
    const data = await res.json();
    if (data.content !== undefined) {
      state.currentFile = filePath;
      codeEditor.value = data.content;
      if (!state.openTabs.includes(filePath)) {
        state.openTabs.push(filePath);
      }
      renderTabs();
      renderFileTree();
    }
  } catch (err) {
    console.error('Error opening file:', err);
  }
}

// Save Current File
async function saveCurrentFile() {
  if (!state.currentFile) return;
  try {
    const res = await fetch('/api/file/write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: state.currentFile, content: codeEditor.value })
    });
    const data = await res.json();
    if (data.success) {
      appendTerminal(`[SUCCESS] Saved ${state.currentFile}`);
      // Refresh preview if index.html
      if (state.currentFile.endsWith('.html')) {
        previewView.src = `/preview/${state.currentFile}?t=${Date.now()}`;
      }
    }
  } catch (err) {
    appendTerminal(`[ERROR] Save failed: ${err.message}`);
  }
}

// Run Code in Terminal
async function runCurrentFile() {
  toggleDock('terminal');
  appendTerminal(`\n$ python3 ${state.currentFile}`);
  try {
    const cmd = state.currentFile.endsWith('.py') ? `python3 ${state.currentFile}` : `cat ${state.currentFile}`;
    const res = await fetch('/api/terminal', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command: cmd })
    });
    const data = await res.json();
    if (data.stdout) appendTerminal(data.stdout);
    if (data.stderr) appendTerminal(`[STDERR] ${data.stderr}`);
    appendTerminal(`\nProcess exited with code ${data.exitCode}\n$ `);
  } catch (err) {
    appendTerminal(`[EXEC ERROR] ${err.message}\n$ `);
  }
}

// Render Tabs
function renderTabs() {
  editorTabs.innerHTML = '';
  state.openTabs.forEach(file => {
    const tab = document.createElement('div');
    tab.className = `tab ${state.currentFile === file ? 'active' : ''}`;
    tab.innerHTML = `<span>${file}</span><span class="tab-close" onclick="closeTab('${file}', event)">×</span>`;
    tab.onclick = () => openFile(file);
    editorTabs.appendChild(tab);
  });
}

function closeTab(file, e) {
  e.stopPropagation();
  state.openTabs = state.openTabs.filter(f => f !== file);
  if (state.currentFile === file) {
    state.currentFile = state.openTabs[0] || null;
    if (state.currentFile) openFile(state.currentFile);
    else codeEditor.value = '';
  }
  renderTabs();
}

// Dock Panels: Terminal vs Live Preview
function toggleDock(view) {
  document.querySelectorAll('.dock-tab').forEach(t => t.classList.remove('active'));
  if (view === 'terminal') {
    document.getElementById('tab-terminal').classList.add('active');
    terminalView.style.display = 'block';
    previewView.style.display = 'none';
  } else {
    document.getElementById('tab-preview').classList.add('active');
    terminalView.style.display = 'none';
    previewView.style.display = 'block';
    previewView.src = `/preview/index.html?t=${Date.now()}`;
  }
}

function appendTerminal(text) {
  state.terminalOutput += text;
  terminalView.innerText = state.terminalOutput;
  terminalView.scrollTop = terminalView.scrollHeight;
}

// Chat & Autonomous Agent Trigger
async function sendChatMessage() {
  const text = chatInput.value.trim();
  if (!text) return;
  chatInput.value = '';

  // Append User Message
  appendMessage('user', text);

  // Assistant Pipeline placeholder
  const pipelineEl = document.createElement('div');
  pipelineEl.className = 'chat-msg assistant';
  pipelineEl.innerHTML = `
    <div class="msg-sender">PRATHAM AI // AUTONOMOUS AGENT</div>
    <div class="msg-body">Initiating autonomous execution...</div>
    <div class="agent-pipeline" id="current-pipeline">
      <div class="agent-phase-tag">[UNDERSTANDING] Parsing requirements...</div>
    </div>
  `;
  chatMessages.appendChild(pipelineEl);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  try {
    const res = await fetch('/api/agent/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ goal: text })
    });
    const data = await res.json();
    
    // Render completed steps
    const pipe = document.getElementById('current-pipeline');
    pipe.innerHTML = '';
    data.activityLog.forEach(step => {
      const stepDiv = document.createElement('div');
      stepDiv.className = 'agent-phase-tag';
      stepDiv.innerText = `[${step.phase}] ${step.title}: ${step.detail}`;
      pipe.appendChild(stepDiv);
    });

    pipelineEl.querySelector('.msg-body').innerHTML = `Task complete. All invariants checked. Executed cleanly with exit code 0.`;
    await fetchFiles();
  } catch (err) {
    pipelineEl.querySelector('.msg-body').innerText = `Agent Error: ${err.message}`;
  }
}

function appendMessage(sender, text) {
  const el = document.createElement('div');
  el.className = `chat-msg ${sender}`;
  el.innerHTML = `
    <div class="msg-sender">${sender === 'user' ? 'USER' : 'PRATHAM AI'}</div>
    <div class="msg-body">${escapeHTML(text)}</div>
  `;
  chatMessages.appendChild(el);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function escapeHTML(str) {
  return str.replace(/[&<>'"]/g, tag => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[tag] || tag));
}

// Command Palette Trigger
function openCommandPalette() {
  paletteModal.classList.remove('hidden');
  paletteInput.value = '';
  paletteInput.focus();
  renderPaletteCommands('');
}

function closeCommandPalette() {
  paletteModal.classList.add('hidden');
}

function renderPaletteCommands(query) {
  paletteList.innerHTML = '';
  const filtered = commands.filter(c => c.name.toLowerCase().includes(query.toLowerCase()));
  filtered.forEach(cmd => {
    const item = document.createElement('div');
    item.className = 'palette-item';
    item.innerText = cmd.name;
    item.onclick = () => {
      closeCommandPalette();
      cmd.action();
    };
    paletteList.appendChild(item);
  });
}

function toggleSidebar() {
  const sb = document.getElementById('sidebar');
  sb.classList.toggle('open');
}

function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  document.body.setAttribute('data-theme', state.theme);
}

function clearChat() {
  chatMessages.innerHTML = '';
}

function promptCreateFile() {
  const name = prompt('Enter new filename (e.g. script.js):');
  if (name) {
    fetch('/api/file/write', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: name, content: '' })
    }).then(() => {
      fetchFiles();
      openFile(name);
    });
  }
}

function promptCreateFolder() {
  const name = prompt('Enter new folder name:');
  if (name) {
    fetch('/api/folder/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: name })
    }).then(() => fetchFiles());
  }
}

// Global Keyboard Shortcuts
function setupEventListeners() {
  window.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K -> Command Palette
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      openCommandPalette();
    }
    // Ctrl/Cmd + S -> Save
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      saveCurrentFile();
    }
    // Ctrl/Cmd + B -> Toggle Sidebar
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
      e.preventDefault();
      toggleSidebar();
    }
    // Ctrl/Cmd + Enter -> Run
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      runCurrentFile();
    }
    // Escape -> Close Overlays
    if (e.key === 'Escape') {
      closeCommandPalette();
    }
  });

  paletteInput.addEventListener('input', (e) => {
    renderPaletteCommands(e.target.value);
  });

  paletteModal.addEventListener('click', (e) => {
    if (e.target === paletteModal) closeCommandPalette();
  });
}

window.onload = init;
