/**
 * Test Suite for PRATHAM AI Autonomous Coding Workspace
 */
const http = require('http');
const path = require('path');
const fs = require('fs');
const { sanitizePath, sanitizeCommand } = require('../server/security');

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`[PASS] ${message}`);
    passed++;
  } else {
    console.error(`[FAIL] ${message}`);
    failed++;
  }
}

async function runTests() {
  console.log("=== RUNNING PRATHAM AI TEST SUITE ===");

  // Test 1: Security Sanitize Path - Traversal Prevention
  const baseDir = '/tmp/pratham-workspace/workspace';
  try {
    sanitizePath(baseDir, '../../etc/passwd');
    assert(false, "Path traversal should have thrown error");
  } catch (err) {
    assert(err.message.includes('Path traversal attempt blocked'), "Security: Path traversal correctly blocked");
  }

  // Test 2: Security Sanitize Path - Valid Relative Path
  try {
    const safe = sanitizePath(baseDir, 'subfolder/test.py');
    assert(safe === path.resolve(baseDir, 'subfolder/test.py'), "Security: Valid path resolved correctly");
  } catch (err) {
    assert(false, `Valid path threw error: ${err.message}`);
  }

  // Test 3: Command Filter
  try {
    sanitizeCommand('rm -rf /');
    assert(false, "Destructive rm -rf / should have thrown error");
  } catch (err) {
    assert(err.message.includes('blocked by security policy'), "Security: Destructive command blocked");
  }

  // Test 4: Autonomous Agent Cycle
  const AutonomousAgent = require('../server/agent');
  const agent = new AutonomousAgent(baseDir);
  const phasesEncountered = [];
  const res = await agent.runTask("Build a Fibonacci generator", (step) => {
    phasesEncountered.push(step.phase);
  });
  assert(res.success === true, "Agent task returned success true");
  assert(phasesEncountered.includes('UNDERSTANDING'), "Agent executed UNDERSTANDING phase");
  assert(phasesEncountered.includes('PLANNING'), "Agent executed PLANNING phase");
  assert(phasesEncountered.includes('COMPLETED'), "Agent executed COMPLETED phase");

  // Summary
  console.log(`\nTests Completed: ${passed} Passed, ${failed} Failed.`);
  if (failed > 0) process.exit(1);
}

runTests().catch(err => {
  console.error("Test runner crashed:", err);
  process.exit(1);
});

  // Test 5: Intentional Debugging Check - Non-existent method trigger
  try {
    const invalidResult = agent.executeUndefinedHyperspaceMethod();
    assert(false, "Calling undefined method should fail");
  } catch (err) {
    assert(true, "Controlled failure detected: undefined method properly threw TypeError");
  }
