const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { sanitizePath, sanitizeCommand } = require('./security');
const AutonomousAgent = require('./agent');

const PORT = process.env.PORT || 3300;
const WORKSPACE_DIR = path.resolve(__dirname, '..', 'workspace');
const PUBLIC_DIR = path.resolve(__dirname, '..', 'public');

if (!fs.existsSync(WORKSPACE_DIR)) fs.mkdirSync(WORKSPACE_DIR, { recursive: true });

const agent = new AutonomousAgent(WORKSPACE_DIR);

// Seed default workspace files if empty
if (fs.readdirSync(WORKSPACE_DIR).length === 0) {
  fs.writeFileSync(path.join(WORKSPACE_DIR, 'app.py'), `# Welcome to PRATHAM AI Autonomous Workspace\n\ndef calculate_fibonacci(n):\n    if n <= 1:\n        return n\n    a, b = 0, 1\n    for _ in range(n - 1):\n        a, b = b, a + b\n    return b\n\nif __name__ == "__main__":\n    print("Fibonacci(12) =", calculate_fibonacci(12))\n`);
  fs.writeFileSync(path.join(WORKSPACE_DIR, 'index.html'), `<!DOCTYPE html>\n<html>\n<head>\n  <title>Pratham AI App Preview</title>\n  <style>\n    body { font-family: -apple-system, sans-serif; background: #0b0f19; color: #00ffcc; text-align: center; padding: 50px; }\n    h1 { font-size: 2.2rem; text-shadow: 0 0 10px rgba(0, 255, 204, 0.4); }\n    p { color: #94a3b8; }\n  </style>\n</head>\n<body>\n  <h1>PRATHAM AI WORKSPACE</h1>\n  <p>Autonomous Coding Environment & Live Preview System</p>\n</body>\n</html>\n`);
  fs.writeFileSync(path.join(WORKSPACE_DIR, 'config.json'), JSON.stringify({ appName: "PrathamAI_App", version: "1.0.0", debug: true }, null, 2));
}

function sendJSON(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 5 * 1024 * 1024) { // 5MB limit
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;

  // Handle CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  try {
    // 1. API: List Files
    if (pathname === '/api/files' && req.method === 'GET') {
      const getTree = (dir, rel = '') => {
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        const result = [];
        for (const entry of entries) {
          const entryRel = path.join(rel, entry.name);
          const fullPath = path.join(dir, entry.name);
          if (entry.isDirectory()) {
            result.push({
              name: entry.name,
              path: entryRel,
              type: 'directory',
              children: getTree(fullPath, entryRel)
            });
          } else {
            result.push({
              name: entry.name,
              path: entryRel,
              type: 'file',
              size: fs.statSync(fullPath).size
            });
          }
        }
        return result;
      };
      return sendJSON(res, 200, { files: getTree(WORKSPACE_DIR) });
    }

    // 2. API: Read File
    if (pathname === '/api/file/read' && req.method === 'GET') {
      const filePath = parsedUrl.searchParams.get('path');
      const safePath = sanitizePath(WORKSPACE_DIR, filePath);
      if (!fs.existsSync(safePath)) {
        return sendJSON(res, 404, { error: 'File not found' });
      }
      const content = fs.readFileSync(safePath, 'utf8');
      return sendJSON(res, 200, { path: filePath, content });
    }

    // 3. API: Write / Create File
    if (pathname === '/api/file/write' && req.method === 'POST') {
      const body = await parseBody(req);
      const safePath = sanitizePath(WORKSPACE_DIR, body.path);
      const parentDir = path.dirname(safePath);
      if (!fs.existsSync(parentDir)) fs.mkdirSync(parentDir, { recursive: true });
      fs.writeFileSync(safePath, body.content || '', 'utf8');
      return sendJSON(res, 200, { success: true, path: body.path });
    }

    // 4. API: Delete File
    if (pathname === '/api/file/delete' && req.method === 'POST') {
      const body = await parseBody(req);
      const safePath = sanitizePath(WORKSPACE_DIR, body.path);
      if (fs.existsSync(safePath)) {
        const stat = fs.statSync(safePath);
        if (stat.isDirectory()) {
          fs.rmdirSync(safePath, { recursive: true });
        } else {
          fs.unlinkSync(safePath);
        }
      }
      return sendJSON(res, 200, { success: true, path: body.path });
    }

    // 5. API: Create Folder
    if (pathname === '/api/folder/create' && req.method === 'POST') {
      const body = await parseBody(req);
      const safePath = sanitizePath(WORKSPACE_DIR, body.path);
      if (!fs.existsSync(safePath)) {
        fs.mkdirSync(safePath, { recursive: true });
      }
      return sendJSON(res, 200, { success: true, path: body.path });
    }

    // 6. API: Execute Terminal Command
    if (pathname === '/api/terminal' && req.method === 'POST') {
      const body = await parseBody(req);
      const cmd = sanitizeCommand(body.command);
      
      exec(cmd, { cwd: WORKSPACE_DIR, timeout: 15000 }, (error, stdout, stderr) => {
        sendJSON(res, 200, {
          command: cmd,
          exitCode: error ? (error.code || 1) : 0,
          stdout: stdout || '',
          stderr: stderr || (error ? error.message : '')
        });
      });
      return;
    }

    // 7. API: Autonomous Agent Goal Run
    if (pathname === '/api/agent/run' && req.method === 'POST') {
      const body = await parseBody(req);
      const goal = body.goal || 'General project analysis';
      const result = await agent.runTask(goal);
      return sendJSON(res, 200, result);
    }

    // 8. API: Live Preview of Workspace
    if (pathname.startsWith('/preview/')) {
      const subpath = pathname.replace('/preview/', '') || 'index.html';
      const safePath = sanitizePath(WORKSPACE_DIR, subpath);
      if (fs.existsSync(safePath) && fs.statSync(safePath).isFile()) {
        const ext = path.extname(safePath).toLowerCase();
        const mimeTypes = {
          '.html': 'text/html',
          '.css': 'text/css',
          '.js': 'text/javascript',
          '.json': 'application/json',
          '.png': 'image/png',
          '.svg': 'image/svg+xml'
        };
        res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
        return res.end(fs.readFileSync(safePath));
      }
      return sendJSON(res, 404, { error: 'Preview asset not found' });
    }

    // 9. Static Frontend Server
    let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const mimeTypes = {
        '.html': 'text/html',
        '.css': 'text/css',
        '.js': 'text/javascript',
        '.json': 'application/json',
        '.svg': 'image/svg+xml'
      };
      res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
      return res.end(fs.readFileSync(filePath));
    }

    // Default 404
    sendJSON(res, 404, { error: 'Endpoint not found' });
  } catch (err) {
    console.error('API Error:', err);
    sendJSON(res, 500, { error: err.message || 'Internal server error' });
  }
});

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`PRATHAM AI Autonomous Workspace running on port ${PORT}`);
  });
}

module.exports = server;
