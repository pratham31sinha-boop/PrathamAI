const path = require('path');

function sanitizePath(baseDir, targetRelativePath) {
  if (!targetRelativePath || typeof targetRelativePath !== 'string') {
    throw new Error('Invalid path parameter');
  }
  // Remove null bytes
  const cleaned = targetRelativePath.replace(/\0/g, '');
  // Resolve absolute target inside baseDir
  const resolved = path.resolve(baseDir, cleaned);
  
  // Enforce boundary strictly
  if (!resolved.startsWith(path.resolve(baseDir))) {
    throw new Error(`Path traversal attempt blocked: ${targetRelativePath}`);
  }
  return resolved;
}

function sanitizeCommand(cmd) {
  if (!cmd || typeof cmd !== 'string') {
    throw new Error('Invalid command string');
  }
  // Disallow destructive root commands
  const blockedPatterns = [/rm\s+-rf\s+\/($|\s)/, /:\(\)\{\s*:\|:&\s*\};:/];
  for (const pattern of blockedPatterns) {
    if (pattern.test(cmd)) {
      throw new Error('Command blocked by security policy');
    }
  }
  return cmd.trim();
}

module.exports = {
  sanitizePath,
  sanitizeCommand
};
