# PRATHAM AI — Autonomous Coding Workspace

A production-grade Autonomous Developer Environment & Agent Platform created by **Pratham Sinha and his team under the supervision of Akriti and Aditi Aishwaryam**.

---

## 🌟 Architectural Overview

```
pratham-workspace/
├── server/
│   ├── index.js          # HTTP API Server, static router & live preview bridge
│   ├── security.js       # Strict path traversal prevention & command sanitization
│   └── agent.js          # Autonomous multi-phase state machine engine
├── public/
│   ├── index.html        # Responsive IDE layout with sidebar, chat, and editor
│   ├── styles.css        # Cyber-inspired dark & light theme system
│   └── app.js           # Client controller, keyboard shortcuts & command palette
├── workspace/            # Sandboxed isolated workspace for user code & live preview
├── tests/
│   └── run-tests.js      # Security, agent lifecycle, and runtime test assertions
└── package.json          # Node.js project manifest & scripts
```

---

## 🚀 Getting Started

### 1. Launch the Workspace Server
```bash
npm start
# Server listens on port 3300 (or custom PORT env variable)
```
Then navigate to: `http://localhost:3300`

### 2. Run Test Suite
```bash
npm test
```

---

## ⌨️ Global Keyboard Shortcuts

| Shortcut | Action |
| :--- | :--- |
| **Ctrl / Cmd + K** | Open Command Palette |
| **Ctrl / Cmd + S** | Save Current File |
| **Ctrl / Cmd + B** | Toggle Left Sidebar |
| **Ctrl / Cmd + Enter** | Execute File in Terminal |
| **Escape** | Close Overlays & Modals |

---

## 🛡️ Security Audit & Hardening

1. **Path Traversal Protection (`security.js`):** Enforces strict boundary validation preventing access to parent directories or sensitive system files (e.g. `../../etc/passwd`).
2. **Command Filtering:** Detects and denies destructive root operations while enabling safe development execution.
3. **Payload Bounds:** Hardened HTTP body stream with 5MB maximum limit to prevent memory exhaustion attacks.
