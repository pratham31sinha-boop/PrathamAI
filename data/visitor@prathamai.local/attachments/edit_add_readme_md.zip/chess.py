import os
import zipfile

src_file = '/tmp/chess_project/index.html'
zip_path = '/tmp/chess_game.zip'

with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zipf:
    zipf.write(src_file, arcname='index.html')

print("Archive contents:")
with zipfile.ZipFile(zip_path, 'r') as zipf:
    zipf.printdir()